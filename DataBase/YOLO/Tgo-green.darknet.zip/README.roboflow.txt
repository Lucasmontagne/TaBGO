
Tgo - v2 Green
==============================

This dataset was exported via roboflow.ai on May 12, 2021 at 6:52 AM GMT

It includes 609 images.
Blocks are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -7 and +7 degrees


